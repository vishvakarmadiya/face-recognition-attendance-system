from tkinter import *
import tkinter as tk
from tkinter import ttk
import qrcode as q
import cv2
def att():
    cap=cv2.VideoCapture(0)
    detector=cv2.QRCodeDetector()
    while True:
        _,img1=cap.read()
        data,one,_=detector.detectAndDecode(img1)
        if data:
            a=data
            break
        cv2.imshow("qrcodescanner app",img1)
        if cv2.waitKey(1)==ord("q"):
            break
att()