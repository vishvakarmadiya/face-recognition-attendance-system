import os
import cv2
import csv
import numpy
import DeleteEmployee
import face_recognition
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from datetime import datetime

def olde():
    '''This function create a window that confirm the employee attendance.'''
    def faceDetection():
        '''This function open the webcam and matches the images.'''
        path='ImageList'
        images=[]
        classNames=[]
        
        myList=os.listdir(path)
        print()
        for image in myList:
            curImage=cv2.imread(f'{path}/{image}')
            images.append(curImage)
            classNames.append(os.path.splitext(image)[0])
        
        def findEncodings():
            encodeList=[]
            for i in images:
                img=cv2.cvtColor(i,cv2.COLOR_BGR2RGB)
                encode=face_recognition.face_encodings(img)[0]
                encodeList.append(encode)
            return encodeList
        
        def storeEmpAttendanceRec(empName):
            emplDataList=[]
            with open('EmployeeAttendance.csv','r') as ref:
                data=csv.reader(ref)
                for i in data:
                    emplDataList.append(i)
            srNo=len(emplDataList)
            storeName=[]
            for i in emplDataList:
                storeName.append(i[1])
            if empName not in storeName:
                now=datetime.now()
                #dateString=now.strftime('%H:%M:%S')
                emplDataList.append([srNo+1,empName,'Present',now])
                with open('EmployeeAttendance.csv','w',newline='') as ref:
                    writeEmpAttData=csv.writer(ref)
                    writeEmpAttData.writerows(emplDataList)
                newEmplList=[]
                with open('EmployeeAttendance.csv','r') as ref:
                    readNewData=csv.reader(ref)
                    for i in readNewData:
                        newEmplList.append(i)
                getvDta=tv.get_children()
                for i in getvDta:
                    tv.delete(i)
                for i in newEmplList:
                    tv.insert('',END,values=tuple(i))
        #   To stop the window press a in the keyboard      


        
        listOfKnown=findEncodings()
        print(len(listOfKnown))
        video_camera=cv2.VideoCapture(0)
        while True:
            success,image=video_camera.read()
            imageSmall=cv2.resize(image,(0,0),None,0.25,0.25)
            imageSmall=cv2.cvtColor(imageSmall,cv2.COLOR_BGR2RGB)

            facesCurFrame=face_recognition.face_locations(imageSmall)
            encodingOfCurFrame=face_recognition.face_encodings(imageSmall,facesCurFrame)

            for encodeFace,facLoc in zip(encodingOfCurFrame,facesCurFrame):
                matches=face_recognition.compare_faces(listOfKnown,encodeFace)
                facDis=face_recognition.face_distance(listOfKnown,encodeFace)
                matchIndex=numpy.argmin(facDis)
                if matches[matchIndex]:
                    nameOfEmployee=classNames[matchIndex].upper()
                    y1,x2,y2,x1=facLoc
                    y1,x2,y2,x1=y1*4,x2*4,y2*4,x1*4
                    cv2.rectangle(image,(x1,y1),(x2,y2),(0,255,0),2)
                    cv2.rectangle(image,(x1,y2-35),(x2,y2),(0,255,0),cv2.FILLED)
                    cv2.putText(image,nameOfEmployee,(x1+6,y2-6),cv2.FONT_HERSHEY_COMPLEX,1,(255,255,253),2)
                    storeEmpAttendanceRec(nameOfEmployee)
                
            cv2.imshow('Employee Attendance Webcam',image)
            c=cv2.waitKey(1)
            if c==ord('a'):
                video_camera.release()
                break
        
    wn=Toplevel()
    wn.title("Old Employee ")
    wn.state('zoomed')
    wn.configure(bg="white",bd=10, relief=RIDGE)
    f1=Frame(wn,bg='skyblue',bd=10, relief=RIDGE)
    f1.pack(side=LEFT,expand=True,fill=BOTH)
    f2=Frame(wn,bg='white',bd=10, relief=RIDGE)
    f2.pack(side=RIGHT,expand=True,fill=BOTH)
    column=('SNo.','Employee Name','Attendance Status','Timing')
    tv=ttk.Treeview(f2,height="28",show='headings',columns=column)
    tv.heading('SNo.',text='SNo.')
    tv.heading('Employee Name',text='Employee Name')
    tv.heading('Attendance Status',text='Attendance Status',)
    tv.heading('Timing',text='Timing')
    tv.column('#1',width=150,anchor=CENTER)
    tv.column('#2',width=200,anchor=CENTER)
    tv.column('#3',width=200,anchor=CENTER)
    tv.column('#4',width=100,anchor=CENTER)

    with open('EmployeeAttendance.csv','a') as ref:
        pass
    empAttendanceList=[]
    with open('EmployeeAttendance.csv','r') as ref:
        empAttData=csv.reader(ref)
        for i in empAttData:
            empAttendanceList.append(i)
    for i in empAttendanceList:
        tv.insert('',END,values=tuple(i))


    tv.place(x=0,y=0,width=700,height=780)
    btn=Button(f1,text='Mark Your Attendance',bg='orange',command=faceDetection)
    btn.place(x=200,y=390,width=150)
    wn.mainloop()
def newe():
    def add():
        list=[]
        a1=e1.get()
        if len(a1)>0:
            if a1.isdigit():
                EmployeeRecList=[]
                with open('Employee.csv','r') as f:
                    data=csv.reader(f)
                    for i in data:
                        EmployeeRecList.append(i)
                srNo=len(EmployeeRecList)
                if int(a1)>srNo:
                    list.append(a1)
                    a2=e2.get().capitalize()
                    if len(a2)>0:
                        if a2[0].isalpha():
                            list.append(a2)
                            a3=e3.get()
                            if len(a3)>0:
                                if a3 in ['Male','Female','M','F','m','f','female','male']:
                                    list.append(a3)
                                    a4=e4.get()
                                    if len(a4)>0:
                                        if len(a4)==12:
                                            if a4.isdigit():
                                                list.append(a4)
                                                a5=e5.get()
                                                if len(a5)>0:
                                                    if len(a5)==10:
                                                        if a5.isdigit():
                                                            list.append(a5)
                                                            a6=e6.get()
                                                            if len(a6)>0:
                                                                if len(a6)>4:
                                                                    list.append(a6)
                                                                    if os.path.exists(r'ImageList/'+a2+'.jpg'):
                                                                        list.append('Yes')
                                                                        tv.insert("",END,values=tuple(list))
                                                                        with open('Employee.csv','a',newline='') as ref:
                                                                            employData=csv.writer(ref)
                                                                            employData.writerow(list)
                                                                        messagebox.showinfo('New Employee Detail Filled Informatiion',list[1]+' employee detail added successfully!')
                                                                    else:
                                                                        messagebox.showinfo('Upload Image','Upload Employee Image!')
                                                                else:
                                                                    messagebox.showinfo('Address Information','Enter address(or correct address).\nIt must contains atleast 4 characters.')
                                                            else:
                                                                messagebox.showinfo('Address Information','Enter Address.')
                                                        else:
                                                            messagebox.showinfo('Mobile Information','Enter correct mobile number.\nIt must be digits.')
                                                    else:
                                                        messagebox.showinfo('Mobile Number Information','Enter correct mobile number.\nIt must be of 10 digits.')
                                                else:
                                                    messagebox.showinfo('Moble Number Information','Enter Mobile Number.')
                                            else:
                                                messagebox.showinfo('Aadhar Number Information','Enter correct aadhar number.\nIt must be digits.')
                                        else:
                                            messagebox.showinfo('Aadhar Number Information','Enter correct aadhar number.\nIt must be of 12 digits.')
                                    else:
                                        messagebox.showinfo('Aadhar Number Information','Enter Aadhar Number.')
                                else:
                                    messagebox.showinfo('Gender Information','Enter correct gender.')
                            else:
                                messagebox.showinfo('Gender Information','Enter Gender')                            
                        else:
                            messagebox.showinfo('Name Information','Enter correct name.\nIt must start with a letter.')
                    else:
                        messagebox.showinfo('Employee Name Information','Enter Employee Name')
                else:
                    messagebox.showinfo('SrNo Information','Enter correct SrNo.\n'+'It must be greater than'+str(srNo)+'.')
            else:
                messagebox.showinfo('SrNo Information','Enter digit as SrNo.')            
        else:
            messagebox.showinfo('SrNo Information','Enter SrNo.')
    def clear():
        e1.delete(0,"end")
        e2.delete(0,"end")
        e3.delete(0,"end")
        e4.delete(0,"end")
        e5.delete(0,"end")
        e6.delete(0,"end")
    def uploadImg():
        '''This function opens webcam and capture image and stored in a folder.'''
        if len(e2.get())>0:
            camera=cv2.VideoCapture(0)
            success,image=camera.read()
            if success:
                cv2.imshow('Employee Image',image)
                cv2.imwrite(r'ImageList/'+e2.get().capitalize()+'.jpg',image)
                cv2.waitKey(0)
                camera.release()
                # cv2.destroyWindow('Employee Image')
            else:
                messagebox.showinfo('Image Error','No image found in webcam.')
        else:
            messagebox.showinfo('Information Fill Reqirement','Fill the above information first')    
    wn=Toplevel()
    wn.title("exit mmember Employee ")
    wn.state('zoomed')
    wn.configure(bg="white")
#----------------------Frame1------------------------#
    f1=Frame(wn,bg="royalblue",height="100",width="1533",bd=10, relief=RIDGE)
    f1.place(y=1,x=1)
##########lavel 1##########
    L1=Label(f1,text="Welcome to Davis Group Of Company",font=("Calibri",50),fg="lightskyblue" ,bg="royalblue")
    L1.place(y=0,x=255)
#----------------------Frame2------------------------#
    f2=Frame(wn,bg="royalblue",height="453",width="570",bd=10, relief=RIDGE)
    f2.place(y=102,x=1)
#----------------------label 6------------------------#
    L6=Label(f2,text="Sr. Number:",font=("Calibri",15),fg="black",bg="royalblue")
    L6.place(y=50,x=50)
#----------------------Entry 6-----------------------#
    e1=Entry(f2,font=("Calibri",15),bg="royalblue",fg="black")
    e1.place(y=50,x=300)
#----------------------label 1------------------------#
    L1=Label(f2,text="Employee Name:",font=("Calibri",15),fg="black",bg="royalblue")
    L1.place(y=100,x=50)
#----------------------Entry 1------------------------#
    e2=Entry(f2,font=("Calibri",15),bg="royalblue",fg="black")
    e2.place(y=100,x=300)
#----------------------label 2------------------------#
    L2=Label(f2,text="Gender:",font=("Calibri",15),fg="black",bg="royalblue")
    L2.place(y=150,x=50)
#----------------------Entry 2------------------------#
    e3=Entry(f2,font=("Calibri",15),bg="royalblue",fg="black")
    e3.place(y=150,x=300)
#----------------------label 3------------------------#
    L3=Label(f2,text="Adhar num:",font=("Calibri",15),fg="black",bg="royalblue")
    L3.place(y=200,x=50)
#----------------------Entry 3------------------------#
    e4=Entry(f2,font=("Calibri",15),bg="royalblue",fg="black")
    e4.place(y=200,x=300)
#----------------------label 4------------------------#
    L4=Label(f2,text="Mobile no:",font=("Calibri",15),fg="black",bg="royalblue")
    L4.place(y=250,x=50)
#----------------------Entry 4------------------------#
    e5=Entry(f2,font=("Calibri",15),bg="royalblue",fg="black")
    e5.place(y=250,x=300)
#----------------------label 5------------------------#
    L5=Label(f2,text="Address:",font=("Calibri",15),fg="black",bg="royalblue")
    L5.place(y=300,x=50)
#----------------------Entry 5------------------------#
    e6=Entry(f2,font=("Calibri",15),bg="royalblue",fg="black")
    e6.place(y=300,x=300)
#----------------------botton1------------------------#
    bt1=Button(wn,font=("Elephant",13),fg="black",bg="royalblue", text="Submit" ,command=add)
    bt1.place(y=455,x=320)
#----------------------Frame4------------------------#
    f4=Frame(wn,bg="royalblue",height="235",width="570",bd=10,relief=RIDGE)
    f4.place(y=553,x=2)
    img01=PhotoImage(file="D:\\python all programs\\python gui\\new employ bottom1.png")
    img02=Label(f4,image=img01)
    img02.place(height="215",width="550",x=0,y=0)
#----------------------Frame3------------------------#
    f3=Frame(wn,bg="royalblue",height="652",width="962",bd=10, relief=RIDGE)
    f3.place(y=102,x=572)
    bt2=Button(wn,font=("Elephant",13),fg="black",bg="royalblue", text="clear" ,command=clear)
    bt2.place(y=455,x=250)
    bt3=Button(wn,font=("Elephant",13),fg="black",bg="royalblue", text="Upload Photo" ,command=uploadImg)
    bt3.place(y=455,x=50)
    t=("sr","fn","ln","An","mn","a","uf")
    tv=ttk.Treeview(f3,height="32",show="headings",columns=t)
    tv.heading("sr",text="Sr.no.")
    tv.heading("fn",text="Employee Name")
    tv.heading("ln",text="Gender")
    tv.heading("An",text="Employee Adhar num")
    tv.heading("mn",text="Mobile no")
    tv.heading("a",text="Address")
    tv.heading("uf",text="Upload Photo")
    tv.column("#1",anchor=CENTER ,width="80")
    tv.column("#2",anchor=CENTER ,width="200")
    tv.column("#3",anchor=CENTER,width="110")
    tv.column("#4",anchor=CENTER,width="200")
    tv.column("#5",anchor=CENTER,width="150")
    tv.column("#6",anchor=CENTER,width="150")
    tv.column("#7",anchor=CENTER,width="50")
    tv.pack(side=TOP)
    with open('Employee.csv','a',newline='') as ref:
        pass
    employeeList=[]
    with open('Employee.csv','r') as ref:
        employeeData=csv.reader(ref)
        for i in employeeData:
            employeeList.append(i)
    for i in employeeList:
        tv.insert('',END,values=tuple(i))
    tv.pack(side=TOP)
    wn.mainloop()

def Exit():
    DeleteEmployee.deleteEmp()

def deleteAccount():
    def submit():
        list=[]
        with open('Authorative.csv','r') as ref:
            rd=csv.reader(ref)
            for i in rd:
                list.append(i)
        if lbPE.get()==list[0][1]:
            with open('Employee.csv','w',newline='')as ref:
                write=csv.writer(ref)
                write.writerows([])

            path=r'ImageList'
            for i in os.listdir(path):
                os.remove(f'{path}/{i}')
            with open('EmployeeAttendance.csv','w',newline='')as ref:
                write=csv.writer(ref)
                write.writerows([])
            list=[]
            with open('Authorative.csv','w')as ref:
                read=csv.writer(ref)
                read.writerows(list)
            messagebox.showinfo('Delete Account','Your account is deleted successfully!')
        else:
            messagebox.showerror('Password Error','Enter correct Authorative password!')



    def forget():
        def check():
            list=[]
            with open('Authorative.csv','r') as ref:
                read=csv.reader(ref)
                for i in read:
                    list.append(i)
            if lbNNE.get()==list[0]:
                nlbnn=Label(pswind,text='Your password is:'+list[1])
                nlbnn.place(x=30,y=195)
            else:
                nlbnn=Label(pswind,text='No record found!')
                nlbnn.place(x=30,y=195)
        lbNN=Label(pswind,text='Enter Authorative Name',bg='skyblue',fg='#191975',font=('Comic Sans MS',12,'bold'))
        lbNN.place(x=20,y=120)
        lbNNE=Entry(pswind,bg='skyblue',fg='#191975',font=('Comic Sans MS',12,'bold'))
        lbNNE.place(x=20,y=145)
        lbPEFB=Button(pswind,text='Submit',command=check,bd=0,bg='#FBF0B2',fg='#191970',font=('Comic Sans MS',10,'bold'))
        lbPEFB.place(x=30,y=170,width=165)
    pswind=Toplevel()
    pswind.title('Delete Account')
    pswind.config(bg='skyblue')
    window_width = 300
    window_height = 350
    # get the screen dimension
    screen_width = pswind.winfo_screenwidth()
    screen_height = pswind.winfo_screenheight()
    # find the center point
    center_x = int(screen_width/2 - window_width / 2)
    center_y = int(screen_height/2 - window_height / 2)
    # set the position of the window to the center of the screen
    pswind.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')
    lbP=Label(pswind,text='Enter Authorative Password',bg='skyblue',fg='#191975',font=('Comic Sans MS',12,'bold'))
    lbP.place(x=20,y=20)
    lbPE=Entry(pswind,text='Enter Authorative Password',show='*',bd=0,bg='#FBF0B2',fg='#191970',font=('Comic Sans MS',10,'bold'))
    lbPE.place(x=20,y=45,width=220)
    lbPEB=Button(pswind,text='Submit',bd=0,activebackground='skyblue',command=submit,bg='skyblue',fg='#191970',font=('Comic Sans MS',10,'bold'))
    lbPEB.place(x=80,y=70,width=100)
    lbPEFB=Button(pswind,text='Forget your password?',command=forget,bd=0,bg='#FBF0B2',fg='#191970',font=('Comic Sans MS',10,'bold'))
    lbPEFB.place(x=30,y=95,width=165)

    pswind.mainloop()



def login():
    path='ImageList'
    if os.path.exists(path):
        pass
    else:
        os.mkdir(path)
    wn=Toplevel()
    wn.title("Employee Attendance")
    wn.state('zoomed')
    wn.configure(bg="white")
    f1=Frame(wn,bg="royalblue",height="100",width="1533",bd=10, relief=RIDGE)
    f1.place(y=1,x=1)
##########lavel 1##########
    L1=Label(f1,text="Employee Attendance With Face-recognition",font=("Calibri",50),fg="lightskyblue" ,bg="royalblue")
    L1.place(y=0,x=200)
    b1=Button(f1,text='Delete Account',bg='skyblue',command=deleteAccount)
    b1.place(x=2,y=0)

#####frame 2#########
    f2=Frame(wn,bg="royalblue",height="217",width="570",bd=10, relief=RIDGE)
    f2.place(y=102,x=1)
##########lavel 2##########
    L2=Label(f2,text="Old employee attendance :",font=("Calibri",20),fg="lightskyblue" ,bg="royalblue")
    L2.place(y=173,x=50)

#----------------------Frame3------------------------#
    f3=Frame(wn,bg="royalblue",height="217",width="570",bd=10, relief=RIDGE)
    f3.place(y=320,x=1)
#----------------------img------------------------#
    img01=PhotoImage(file="D:\\python all programs\\python gui\\old emloyee1.png")
    img02=Label(f2,image=img01)
    img02.place(height="170",width="550",x=0,y=0)
#----------------------label3------------------------#
    L3=Label(f3,text="New employee attendance :",font=("Calibri",20),fg="lightskyblue" ,bg="royalblue")
    L3.place(y=173,x=50)

#----------------------img------------------------#
    img03=PhotoImage(file="D:\\python all programs\\python gui\\new emply1.png")
    img3=Label(f3,image=img03)
    img3.place(height="170",width="550",x=0,y=0)
#----------------------Frame4------------------------#
    f4=Frame(wn,bg="royalblue",height="217",width="570",bd=10, relief=RIDGE)
    f4.place(y=539,x=1)
#----------------------label3------------------------#
    L5=Label(f4,text="The employee exit on place:",font=("Calibri",20),fg="lightskyblue" ,bg="royalblue")
    L5.place(y=173,x=50)

#----------------------img------------------------#
    img04=PhotoImage(file="D:\\python all programs\\python gui\\when employee leav1.png")
    img4=Label(f4,image=img04)
    img4.place(height="170",width="550",x=0,y=0)
#----------------------Frame5------------------------#
    f5=Frame(wn,bg="royalblue",height="50",width="570",bd=10, relief=RIDGE)
    f5.place(y=756,x=1)
#----------------------buttons------------------------#
    bt1=Button(f5,font=("Elephant",10),bg="lightskyblue" ,fg="royalblue", text="Employee Attendance",command=lambda:olde())
    bt1.place(y=1,x=0)
    bt2=Button(f5,font=("Elephant",10),bg="lightskyblue" ,fg="royalblue", text="Add New Employee",command=newe)
    bt2.place(y=1,x=220)
    bt3=Button(f5,font=("Elephant",10),bg="lightskyblue" ,fg="royalblue", text="Delete Employee",command=Exit)
    bt3.place(y=1,x=424)

#frame 6
    f6=Frame(wn,bg="royalblue",height="689.5",width="962",bd=10, relief=RIDGE)
    f6.place(y=102,x=572)
#1img use karna onty png
    img1=PhotoImage(file="D:\\python all programs\\python gui\\newfile.png")
    img2=Label(f6,image=img1)
    img2.place(height="669",width="940",x=0,y=0)
    wn.mainloop()

